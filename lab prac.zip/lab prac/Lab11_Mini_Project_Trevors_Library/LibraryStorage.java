/*
 * Trevor's Library - saves and loads the library as three CSV files
 * Author: Trevor
 *
 * Files written to the data folder:
 *   items.csv   type,id,title,extra          (extra = author for books, minutes for DVDs)
 *   members.csv id,name
 *   loans.csv   itemId,memberId,loanDate     (only loans that are still open)
 */

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LibraryStorage {

    private final Path folder;

    public LibraryStorage(Path folder) {
        this.folder = folder;
    }

    public void save(Library library) throws IOException {
        Files.createDirectories(folder);

        List<String> itemLines = new ArrayList<>();
        itemLines.add("type,id,title,extra");
        for (LibraryItem item : library.allItems()) {
            itemLines.add(item.typeCode() + "," + item.getId() + "," + item.getTitle()
                    + "," + item.extraField());
        }
        Files.write(folder.resolve("items.csv"), itemLines);

        List<String> memberLines = new ArrayList<>();
        memberLines.add("id,name");
        for (Member member : library.allMembers()) {
            memberLines.add(member.getId() + "," + member.getName());
        }
        Files.write(folder.resolve("members.csv"), memberLines);

        List<String> loanLines = new ArrayList<>();
        loanLines.add("itemId,memberId,loanDate");
        for (Member member : library.allMembers()) {
            for (Loan loan : member.getActiveLoans()) {
                loanLines.add(loan.getItem().getId() + "," + member.getId() + ","
                        + loan.getLoanDate());
            }
        }
        Files.write(folder.resolve("loans.csv"), loanLines);
    }

    /** Returns an empty library on the first run, when no data has been saved yet. */
    public Library load() throws IOException {
        Library library = new Library();
        Path itemFile = folder.resolve("items.csv");
        if (!Files.exists(itemFile)) {
            return library;
        }

        List<String> itemLines = Files.readAllLines(itemFile);
        for (int i = 1; i < itemLines.size(); i++) {          // line 0 is the header
            String line = itemLines.get(i);
            if (line.isBlank()) continue;
            String[] p = line.split(",", -1);
            try {
                if (p.length != 4) throw new IllegalArgumentException("expected 4 fields");
                switch (p[0]) {
                    case "BOOK" -> library.addItem(new Book(p[1], p[2], p[3]));
                    case "DVD"  -> library.addItem(new Dvd(p[1], p[2], Integer.parseInt(p[3])));
                    default     -> throw new IllegalArgumentException("unknown type " + p[0]);
                }
            } catch (IllegalArgumentException e) {
                throw new IOException("items.csv line " + (i + 1) + ": " + e.getMessage(), e);
            }
        }

        List<String> memberLines = Files.readAllLines(folder.resolve("members.csv"));
        for (int i = 1; i < memberLines.size(); i++) {
            String line = memberLines.get(i);
            if (line.isBlank()) continue;
            String[] p = line.split(",", -1);
            try {
                if (p.length != 2) throw new IllegalArgumentException("expected 2 fields");
                library.registerMember(new Member(p[0], p[1]));
            } catch (IllegalArgumentException e) {
                throw new IOException("members.csv line " + (i + 1) + ": " + e.getMessage(), e);
            }
        }

        Path loanFile = folder.resolve("loans.csv");
        if (Files.exists(loanFile)) {
            List<String> loanLines = Files.readAllLines(loanFile);
            for (int i = 1; i < loanLines.size(); i++) {
                String line = loanLines.get(i);
                if (line.isBlank()) continue;
                String[] p = line.split(",", -1);
                try {
                    if (p.length != 3) throw new IllegalArgumentException("expected 3 fields");
                    // Re-lending through the normal borrow method rebuilds the loan and its due date
                    library.borrow(p[1], p[0], LocalDate.parse(p[2]));
                } catch (IllegalArgumentException | ItemNotAvailableException
                         | MemberLimitExceededException e) {
                    throw new IOException("loans.csv line " + (i + 1) + ": " + e.getMessage(), e);
                }
            }
        }
        return library;
    }
}
