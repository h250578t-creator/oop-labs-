/*
 * Trevor's Library - a registered library member
 * Author: Trevor
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Member {

    /** EXPLAIN: a constant - the loan limit lives in one place. */
    public static final int MAX_LOANS = 3;

    private final String id;
    private final String name;
    private final List<Loan> activeLoans = new ArrayList<>();

    public Member(String id, String name) {
        this.id = Validation.text(id, "Member id");
        this.name = Validation.text(name, "Member name");
    }

    public boolean canBorrow() {
        return activeLoans.size() < MAX_LOANS;
    }

    // EXPLAIN: package-private - only the library classes change a member's loans
    void addLoan(Loan loan)    { activeLoans.add(loan); }
    void removeLoan(Loan loan) { activeLoans.remove(loan); }

    // EXPLAIN: returns a read-only view (the defensive copy lesson from Lab 3)
    public List<Loan> getActiveLoans() {
        return Collections.unmodifiableList(activeLoans);
    }

    public String getId()   { return id; }
    public String getName() { return name; }

    @Override
    public String toString() {
        return String.format("[MEMBER] %s | %s | %d of %d loans used", id, name,
                activeLoans.size(), MAX_LOANS);
    }
}
