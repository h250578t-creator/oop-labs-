/*
 * Trevor's Library - Borrowable interface
 * Author: Trevor
 *
 * Any library item that can be lent out implements this contract.
 */

import java.time.LocalDate;

public interface Borrowable {

    /** Lends the item to the member on the given date. */
    void borrow(Member member, LocalDate loanDate) throws ItemNotAvailableException, MemberLimitExceededException;

    // EXPLAIN: default method - uses today's date, so callers can write borrow(member)
    default void borrow(Member member) throws ItemNotAvailableException, MemberLimitExceededException {
        borrow(member, LocalDate.now());
    }

    /** Returns the item to the library. */
    void giveBack();
}
