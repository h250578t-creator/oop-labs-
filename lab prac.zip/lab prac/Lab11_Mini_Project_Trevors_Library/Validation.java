/*
 * Trevor's Library - input validation helper
 * Author: Trevor
 */

/** Shared checks used by the classes that store text (the CSV file needs commas to be avoided). */
final class Validation {

    private Validation() { }   // utility class: no objects needed

    /** Returns the trimmed text, or throws if it is blank or contains a comma. */
    static String text(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " is required");
        }
        if (value.contains(",")) {
            throw new IllegalArgumentException(fieldName + " cannot contain commas");
        }
        return value.trim();
    }
}
