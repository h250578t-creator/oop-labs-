/*
 * Trevor's Library - one item lent to one member
 * Author: Trevor
 */

import java.time.LocalDate;

public class Loan {

    private final LibraryItem item;
    private final Member member;
    private final LocalDate loanDate;
    private final LocalDate dueDate;

    // EXPLAIN: package-private - only LibraryItem creates loans
    Loan(LibraryItem item, Member member, LocalDate loanDate, LocalDate dueDate) {
        this.item = item;
        this.member = member;
        this.loanDate = loanDate;
        this.dueDate = dueDate;
    }

    /** A loan is overdue when today is after the due date. */
    public boolean isOverdue(LocalDate today) {
        return today.isAfter(dueDate);
    }

    public LibraryItem getItem()   { return item; }
    public Member getMember()      { return member; }
    public LocalDate getLoanDate() { return loanDate; }
    public LocalDate getDueDate()  { return dueDate; }

    @Override
    public String toString() {
        return String.format("%s lent to %s, due %s", item.getTitle(), member.getName(), dueDate);
    }
}
