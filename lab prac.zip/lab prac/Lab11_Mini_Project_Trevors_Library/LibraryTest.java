/*
 * Trevor's Library - automated checks for the core behaviour
 * Author: Trevor
 *
 * Run this class to see PASS or FAIL for each check. It uses fixed dates so the
 * results do not change from day to day.
 */

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

public class LibraryTest {

    /** A piece of code that may throw; used to check which exception is thrown. */
    interface Action {
        void run() throws Exception;
    }

    private static int failures = 0;

    public static void main(String[] args) throws Exception {
        LocalDate day = LocalDate.of(2026, 10, 1);

        // 1. Polymorphism: each item type has its own loan period
        LibraryItem[] items = { new Book("B-1", "Ash on the Kopje", "Chiedza Nyathi"),
                                new Dvd("D-1", "Harare Nights", 95) };
        check("Book lends for 21 days", items[0].loanPeriodDays() == 21);
        check("DVD lends for 7 days", items[1].loanPeriodDays() == 7);

        // 2. Borrowing marks the item unavailable and records the loan
        Library lib = new Library();
        Book book = new Book("B-2", "The Quiet Mbira", "Munyaradzi Gwena");
        lib.addItem(book);
        lib.registerMember(new Member("M-1", "Rumbidzai Mhandu"));
        lib.registerMember(new Member("M-2", "Tafadzwa Chirwa"));
        lib.borrow("M-1", "B-2", day);
        check("borrowed item is not available", !book.isAvailable());
        check("loan due date is 21 days later",
              book.getCurrentLoan().getDueDate().equals(day.plusDays(21)));

        // 3. A second borrow of the same item is refused
        check("second borrow throws ItemNotAvailableException",
              throwsType(ItemNotAvailableException.class, () -> lib.borrow("M-2", "B-2", day)));

        // 4. Returning the item makes it available again
        lib.giveBack("B-2");
        check("returned item is available", book.isAvailable());
        check("giving back an item that is not on loan is refused",
              throwsType(IllegalStateException.class, () -> lib.giveBack("B-2")));

        // 5. Loan limit: a fourth loan is refused
        for (int i = 3; i <= 5; i++) {
            lib.addItem(new Book("B-" + i, "Dust Road " + i, "Kudakwashe Mavhunga"));
        }
        lib.borrow("M-1", "B-3", day);
        lib.borrow("M-1", "B-4", day);
        lib.borrow("M-1", "B-5", day);
        lib.addItem(new Dvd("D-9", "Kopje Stories", 80));
        check("fourth loan throws MemberLimitExceededException",
              throwsType(MemberLimitExceededException.class, () -> lib.borrow("M-1", "D-9", day)));
        check("refused item stays available", lib.allItems().stream()
              .anyMatch(i -> i.getId().equals("D-9") && i.isAvailable()));

        // 6. Overdue loans: nothing overdue on the loan day, the DVD is overdue a week later
        Library overdueLib = new Library();
        overdueLib.addItem(new Dvd("D-2", "Harare Nights", 95));
        overdueLib.registerMember(new Member("M-3", "Ruvimbo Dube"));
        overdueLib.borrow("M-3", "D-2", day);                 // due 8 October
        check("no overdue loans on 5 October", overdueLib.overdueLoans(LocalDate.of(2026, 10, 5)).isEmpty());
        check("DVD is overdue on 20 October", overdueLib.overdueLoans(LocalDate.of(2026, 10, 20)).size() == 1);

        // 7. Search is case-insensitive and returns sorted results
        Library searchLib = new Library();
        searchLib.addItem(new Book("B-10", "Kopje Morning", "Chiedza Nyathi"));
        searchLib.addItem(new Dvd("D-10", "kopje Night Walk", 60));
        searchLib.addItem(new Book("B-11", "River Songs", "Tawanda Moyo"));
        List<LibraryItem> found = searchLib.searchByTitle("KOPJE");
        check("search finds two titles", found.size() == 2);
        check("search results are sorted by title",
              found.get(0).getTitle().equals("Kopje Morning"));

        // 8. Input validation
        check("commas in a title are rejected",
              throwsType(IllegalArgumentException.class, () -> new Book("B-12", "Bad,Title", "Someone")));
        check("blank author is rejected",
              throwsType(IllegalArgumentException.class, () -> new Book("B-13", "Title", "  ")));
        check("zero running time is rejected",
              throwsType(IllegalArgumentException.class, () -> new Dvd("D-13", "Title", 0)));
        check("duplicate item id is rejected",
              throwsType(IllegalArgumentException.class, () -> searchLib.addItem(new Book("B-10", "Other", "Someone"))));
        check("unknown member id is rejected",
              throwsType(IllegalArgumentException.class, () -> lib.borrow("M-99", "B-2", day)));

        // 9. Saving and loading gives back the same library
        Path folder = Files.createTempDirectory("trevors-library-test");
        LibraryStorage storage = new LibraryStorage(folder);
        storage.save(lib);                                       // lib has one open loan: M-1 has B-3, B-4, B-5
        Library reloaded = storage.load();
        check("reloaded library has the same items", reloaded.allItems().size() == lib.allItems().size());
        check("reloaded library has the same members", reloaded.allMembers().size() == lib.allMembers().size());
        check("reloaded loans are still open", reloaded.allItems().stream()
              .filter(i -> !i.isAvailable()).count() == 3);
        LibraryItem reloadedBook = reloaded.allItems().stream()
              .filter(i -> i.getId().equals("B-3")).findFirst().orElseThrow();
        check("reloaded loan keeps its original date",
              reloadedBook.getCurrentLoan().getLoanDate().equals(day));

        System.out.println();
        System.out.println(failures == 0 ? "All checks passed." : failures + " check(s) FAILED.");
        if (failures > 0) {
            System.exit(1);
        }
    }

    private static void check(String name, boolean condition) {
        if (condition) {
            System.out.println("PASS - " + name);
        } else {
            failures++;
            System.out.println("FAIL - " + name);
        }
    }

    /** Returns true if the action throws an exception of the given type. */
    private static boolean throwsType(Class<? extends Throwable> type, Action action) {
        try {
            action.run();
            return false;
        } catch (Throwable t) {
            return type.isInstance(t);
        }
    }
}
