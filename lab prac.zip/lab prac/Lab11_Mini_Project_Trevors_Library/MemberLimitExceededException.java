/*
 * Trevor's Library - thrown when a member already has the maximum number of loans
 * Author: Trevor
 */

// EXPLAIN: checked exception - the caller must catch it or declare it
public class MemberLimitExceededException extends Exception {
    private static final long serialVersionUID = 1L;   // EXPLAIN: required by the Serializable warning; not used for saving
    public MemberLimitExceededException(String message) {
        super(message);
    }
}
