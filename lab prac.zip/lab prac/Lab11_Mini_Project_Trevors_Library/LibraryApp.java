/*
 * Trevor's Library - the menu program (run this class)
 * Author: Trevor
 */

import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class LibraryApp {

    private static final Path DATA_FOLDER = Path.of("data");

    public static void main(String[] args) {
        System.out.println("=== Trevor's Library Management System ===");

        LibraryStorage storage = new LibraryStorage(DATA_FOLDER);
        Library library;
        try {
            library = storage.load();
            System.out.println("Loaded " + library.allItems().size() + " items and "
                    + library.allMembers().size() + " members.");
        } catch (IOException e) {
            System.out.println("Could not load saved data: " + e.getMessage());
            return;
        }

        Scanner in = new Scanner(System.in);
        boolean running = true;
        while (running) {
            printMenu();
            try {
                String choice = in.nextLine().trim();
                switch (choice) {
                    case "1" -> addItem(in, library);
                    case "2" -> registerMember(in, library);
                    case "3" -> borrow(in, library);
                    case "4" -> giveBack(in, library);
                    case "5" -> listOverdue(library);
                    case "6" -> search(in, library);
                    case "7" -> listItems(library);
                    case "8" -> listMembers(library);
                    case "0" -> running = false;
                    default  -> System.out.println("Please choose a number from the menu.");
                }
            } catch (ItemNotAvailableException | MemberLimitExceededException
                     | IllegalArgumentException | IllegalStateException e) {
                // EXPLAIN: each expected problem is reported and the menu continues
                System.out.println("Error: " + e.getMessage());
            } catch (NoSuchElementException e) {
                break;   // end of input (for example, a piped file ended)
            }
            System.out.println();
        }

        try {
            storage.save(library);
            System.out.println("Data saved. Goodbye!");
        } catch (IOException e) {
            System.out.println("Could not save data: " + e.getMessage());
        }
    }

    private static void printMenu() {
        System.out.println("1. Add item (book or DVD)");
        System.out.println("2. Register member");
        System.out.println("3. Borrow an item");
        System.out.println("4. Return an item");
        System.out.println("5. List overdue loans");
        System.out.println("6. Search by title");
        System.out.println("7. List all items");
        System.out.println("8. List all members");
        System.out.println("0. Save and exit");
        System.out.print("Choice: ");
    }

    private static void addItem(Scanner in, Library library) {
        System.out.print("Type (B = book, D = DVD): ");
        String type = in.nextLine().trim().toUpperCase();
        System.out.print("Item id (for example B-101): ");
        String id = in.nextLine();
        System.out.print("Title: ");
        String title = in.nextLine();

        if (type.equals("B")) {
            System.out.print("Author: ");
            library.addItem(new Book(id, title, in.nextLine()));   // polymorphism: a Book is a LibraryItem
        } else if (type.equals("D")) {
            System.out.print("Running time in minutes: ");
            int minutes = Integer.parseInt(in.nextLine().trim());  // bad input -> NumberFormatException
            library.addItem(new Dvd(id, title, minutes));
        } else {
            throw new IllegalArgumentException("Type must be B or D");
        }
        System.out.println("Item added.");
    }

    private static void registerMember(Scanner in, Library library) {
        System.out.print("Member id (for example M-01): ");
        String id = in.nextLine();
        System.out.print("Member name: ");
        library.registerMember(new Member(id, in.nextLine()));
        System.out.println("Member registered.");
    }

    private static void borrow(Scanner in, Library library)
            throws ItemNotAvailableException, MemberLimitExceededException {
        System.out.print("Member id: ");
        String memberId = in.nextLine();
        System.out.print("Item id: ");
        String itemId = in.nextLine();
        library.borrow(memberId, itemId);
        System.out.println("Item lent out.");
    }

    private static void giveBack(Scanner in, Library library) {
        System.out.print("Item id: ");
        library.giveBack(in.nextLine());
        System.out.println("Item returned.");
    }

    private static void listOverdue(Library library) {
        List<Loan> overdue = library.overdueLoans(LocalDate.now());
        if (overdue.isEmpty()) {
            System.out.println("No overdue loans.");
        }
        for (Loan loan : overdue) {
            System.out.println("OVERDUE: " + loan);
        }
    }

    private static void search(Scanner in, Library library) {
        System.out.print("Search text: ");
        List<LibraryItem> found = library.searchByTitle(in.nextLine());
        if (found.isEmpty()) {
            System.out.println("No matching titles.");
        }
        found.forEach(System.out::println);
    }

    private static void listItems(Library library) {
        library.allItems().forEach(System.out::println);
    }

    private static void listMembers(Library library) {
        library.allMembers().forEach(System.out::println);
    }
}
