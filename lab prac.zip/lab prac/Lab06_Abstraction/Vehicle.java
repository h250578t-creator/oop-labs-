/*
 * Lab 6 - Program 6.1: Abstract class Vehicle
 * Author: Trevor
 */

abstract class Vehicle {
    private final String plate;

    Vehicle(String plate) { this.plate = plate; }   // EXPLAIN: abstract classes CAN have constructors

    // EXPLAIN: abstract -> no body; every concrete subclass MUST provide one
    abstract double fuelCostPerKm();

    // concrete method shared by all vehicles (template of common behaviour)
    double tripCost(double km) {
        return km * fuelCostPerKm();
    }

    String getPlate() { return plate; }
}
