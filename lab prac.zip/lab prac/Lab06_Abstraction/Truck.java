/*
 * Lab 6 - Program 6.1: Truck, a concrete Vehicle
 * Author: Trevor
 */

class Truck extends Vehicle {
    Truck(String plate) { super(plate); }
    @Override double fuelCostPerKm() { return 0.80; }
}
