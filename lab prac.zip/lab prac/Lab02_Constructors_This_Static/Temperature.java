/* Author: Trevor */

/**
 * Exercise 5 (Challenge): Temperature with static factory methods and a private constructor.
 *
 * Why static factories can be clearer than overloaded constructors
 * -----------------------------------------------------------------
 * 1. Same signature problem: both "from Celsius" and "from Fahrenheit" take one double.
 *    Two constructors Temperature(double) and Temperature(double) would not compile,
 *    because overloads must differ in their parameter types. Named factory methods
 *    (fromCelsius, fromFahrenheit) remove the ambiguity entirely.
 * 2. Readable at the call site: Temperature.fromFahrenheit(212) states the unit,
 *    while new Temperature(212) hides it.
 * 3. Control: the constructor can be private, so all creation goes through checks
 *    and conversions. A factory can also return a cached object, or a subtype,
 *    which a constructor cannot do.
 * 4. Clear names: a factory can have a descriptive name, and it does not have to
 *    create a new object every time.
 */
public final class Temperature {

    // EXPLAIN: the lowest possible temperature, -273.15 C (0 K)
    private static final double ABSOLUTE_ZERO_C = -273.15;

    // EXPLAIN: store ONE canonical unit internally (Celsius); convert on the way in and out
    private final double celsius;

    // EXPLAIN: private constructor - callers must use a factory method
    private Temperature(double celsius) {
        if (celsius < ABSOLUTE_ZERO_C) {
            throw new IllegalArgumentException(
                    "Temperature below absolute zero: " + celsius + " C");
        }
        this.celsius = celsius;
    }

    /** Factory: create a Temperature from a Celsius value. */
    public static Temperature fromCelsius(double celsius) {
        return new Temperature(celsius);
    }

    /** Factory: create a Temperature from a Fahrenheit value (converted to Celsius). */
    public static Temperature fromFahrenheit(double fahrenheit) {
        // Formula: C = (F - 32) x 5 / 9
        return new Temperature((fahrenheit - 32) * 5.0 / 9.0);
    }

    public double getCelsius() {
        return celsius;
    }

    public double getFahrenheit() {
        // Formula: F = C x 9 / 5 + 32
        return celsius * 9.0 / 5.0 + 32;
    }

    public double getKelvin() {
        // Kelvin is Celsius shifted so that absolute zero is 0
        return celsius - ABSOLUTE_ZERO_C;
    }

    @Override
    public String toString() {
        return String.format("%.2f C = %.2f F (%.2f K)", celsius, getFahrenheit(), getKelvin());
    }

    public static void main(String[] args) {
        Temperature boiling = Temperature.fromCelsius(100);
        Temperature freezing = Temperature.fromFahrenheit(32);
        Temperature hot = Temperature.fromFahrenheit(212);

        System.out.println(boiling);
        System.out.println(freezing);
        System.out.println(hot);

        // Invalid input is rejected by the private constructor's check
        try {
            Temperature.fromCelsius(-300);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}
