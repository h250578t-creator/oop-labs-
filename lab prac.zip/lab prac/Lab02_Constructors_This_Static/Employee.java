/* Author: Trevor */

/**
 * Exercise 3 (Intermediate): Employee with an auto-incrementing id,
 * three overloaded constructors and a copy constructor.
 *
 * Lab 2 concepts used:
 *  - static counter for auto-increment ids
 *  - instance initialiser block (runs before a constructor body)
 *  - overloaded constructors chained with this(...)
 *  - copy constructor
 */
public class Employee {

    // EXPLAIN: static counter - shared by ALL employees, gives each new employee the next id
    private static int nextId = 1000;

    // EXPLAIN: default salary used by the constructor that does not receive one
    private static final double DEFAULT_SALARY = 2000.0;

    // EXPLAIN: instance fields - each employee has its own values
    private final int employeeId;
    private final String name;
    private final String department;
    private final double salary;

    /*
     * EXPLAIN: instance initialiser block.
     * It runs once per object, just before the body of the constructor that calls
     * super() (every constructor here ends up in the full constructor below, through
     * this(...)). Assigning the final field 'employeeId' here gives each object a new id.
     */
    {
        employeeId = nextId++;   // use the current value, THEN add 1 for the next employee
    }

    // Constructor 1 (full): every value is supplied by the caller
    public Employee(String name, String department, double salary) {
        if (salary < 0) {
            throw new IllegalArgumentException("Salary cannot be negative");
        }
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    // Constructor 2: name and department; salary uses the default
    public Employee(String name, String department) {
        this(name, department, DEFAULT_SALARY);   // EXPLAIN: chain to constructor 1
    }

    // Constructor 3: name only; department is "Unassigned" and salary is the default
    public Employee(String name) {
        this(name, "Unassigned");                 // EXPLAIN: chain to constructor 2
    }

    /*
     * Copy constructor: builds a new Employee with the same name, department and salary.
     * EXPLAIN: the copy is a NEW object, so it receives a NEW employeeId from the
     * instance initialiser. Two staff records must never share an id.
     */
    public Employee(Employee other) {
        this(other.name, other.department, other.salary);
    }

    public int getEmployeeId() { return employeeId; }
    public String getName()    { return name; }
    public String getDepartment() { return department; }
    public double getSalary()  { return salary; }

    @Override
    public String toString() {
        return String.format("#%d %s | %s | %.2f", employeeId, name, department, salary);
    }

    public static void main(String[] args) {
        Employee e1 = new Employee("Ada", "IT", 4200);   // full constructor
        Employee e2 = new Employee("Ben", "HR");         // name + department
        Employee e3 = new Employee("Cara");              // name only
        Employee e4 = new Employee(e1);                  // copy of Ada

        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);
        System.out.println(e4);   // same details as e1, but a different id
    }
}
