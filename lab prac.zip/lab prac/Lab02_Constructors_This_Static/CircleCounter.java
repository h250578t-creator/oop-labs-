/* Author: Trevor */

/**
 * Exercise 2 (Basic): CircleCounter that keeps a static counter of how many
 * CircleCounter objects have been created, exposed through a static getter.
 *
 * Lab 2 concepts used:
 *  - static fields (one copy shared by all objects)
 *  - static methods (called on the class, no 'this')
 *  - constructor chaining, so the counter is updated in ONE place
 */
public class CircleCounter {

    // EXPLAIN: static field -> ONE counter shared by every CircleCounter object.
    // It belongs to the class, not to any particular circle.
    private static int count = 0;

    // EXPLAIN: instance field -> each CircleCounter has its own radius
    private final double radius;

    /**
     * Full constructor. The counter is incremented here, and every other
     * constructor delegates to this one, so each object is counted exactly once.
     */
    public CircleCounter(double radius) {
        if (radius <= 0) {
            throw new IllegalArgumentException("Radius must be positive: " + radius);
        }
        this.radius = radius;
        count++;   // EXPLAIN: runs once per created object
    }

    /** No-argument constructor: delegates, so it is counted by the constructor above. */
    public CircleCounter() {
        this(1.0);
    }

    /**
     * Static getter: called as CircleCounter.getCount(), no object needed.
     * EXPLAIN: a static method has no 'this', so it can only touch static fields directly.
     */
    public static int getCount() {
        return count;
    }

    public double area() {
        return Math.PI * radius * radius;
    }

    @Override
    public String toString() {
        return String.format("CircleCounter[radius=%.2f]", radius);
    }

    public static void main(String[] args) {
        // EXPLAIN: no circles have been created yet, so the counter is 0
        System.out.println("Circles at start: " + CircleCounter.getCount());

        CircleCounter a = new CircleCounter(2.0);
        CircleCounter b = new CircleCounter();
        System.out.println("After creating 2 circles: " + CircleCounter.getCount());

        CircleCounter c = new CircleCounter(3.5);
        System.out.println("After creating a third circle: " + CircleCounter.getCount());

        // NOTE: the counter only goes UP. Java has no destructors, and objects
        // that are no longer used are removed by garbage collection, which does
        // not change this counter. A counter therefore means "created so far".
        System.out.println(a + " " + b + " " + c);
    }
}
