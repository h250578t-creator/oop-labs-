/* Author: Trevor */

/**
 * Exercise 1 (Basic): Circle with a constructor taking a radius
 * and a no-argument constructor that defaults the radius to 1.0.
 *
 * Lab 2 concepts used:
 *  - constructors (same name as the class, no return type)
 *  - constructor overloading
 *  - this(...) constructor chaining
 */
public class Circle {

    // EXPLAIN: an instance field - every Circle object has its own radius
    private final double radius;

    /**
     * Full constructor: the caller supplies the radius.
     */
    public Circle(double radius) {
        // Validation (from Lab 3): a circle must have a positive radius
        if (radius <= 0) {
            throw new IllegalArgumentException("Radius must be positive: " + radius);
        }
        // EXPLAIN: 'this.radius' is the field, 'radius' on the right is the parameter
        this.radius = radius;
    }

    /**
     * No-argument constructor: defaults the radius to 1.0.
     */
    public Circle() {
        this(1.0);   // EXPLAIN: this(...) must be the FIRST statement; it reuses the constructor above
    }

    public double getRadius() {
        return radius;
    }

    public double area() {
        return Math.PI * radius * radius;   // pi * r^2
    }

    public double circumference() {
        return 2 * Math.PI * radius;        // 2 * pi * r
    }

    @Override
    public String toString() {
        return String.format("Circle[radius=%.2f, area=%.2f, circumference=%.2f]",
                radius, area(), circumference());
    }

    public static void main(String[] args) {
        Circle big = new Circle(5.0);   // uses the radius-taking constructor
        Circle unit = new Circle();     // uses the no-argument constructor -> radius 1.0

        System.out.println(big);
        System.out.println(unit);
    }
}
